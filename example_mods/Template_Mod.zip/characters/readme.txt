Put your custom character .json files here!
and put your .hx or lua files files here! (optional)